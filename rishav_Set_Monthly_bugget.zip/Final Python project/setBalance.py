from credential import user
from credential import Credentials

class give_value:
    def _init_(self,username,value):
        self.username=username
        self.value=value

    
