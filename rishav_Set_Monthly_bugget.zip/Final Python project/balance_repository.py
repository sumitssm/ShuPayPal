from Accounts import Balance
from setBanance import give_value
class balanceRepository:
    def _init_(self):
        self.give_value=[varify(user1,100,True),
                         varify(user2,500,False)]

    def setYourBalance(self,give_value):
        while !(self.give_value<balance):
            self.give_value=False
        else:
            monthly_bal=self.give_value
        return monthly_bal
            
            
